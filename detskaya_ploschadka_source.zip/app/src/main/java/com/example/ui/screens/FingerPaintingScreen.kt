package com.example.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.audio.SoundEffectPlayer
import com.example.data.GameRepository
import com.example.shared.*
import com.example.shared.scene.*
import com.example.ui.components.CanvasBrushMode
import com.example.ui.components.MultitouchRainbowCanvas
import com.example.ui.components.MultitouchStroke
import com.example.ui.components.StampElement
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.random.Random

val PAPER_COLORS = listOf(
    Color(0xFFFFFFFF), // White
    Color(0xFFFFF3B0), // Yellow
    Color(0xFFD6F0FF), // Light Blue
    Color(0xFFFFE0EE)  // Pink
)

val PALETTE_COLORS_8 = listOf(
    Color(0xFFFF1744), // Red
    Color(0xFFFF9100), // Orange
    Color(0xFFFFD600), // Yellow
    Color(0xFF00E676), // Green
    Color(0xFF00E5FF), // Cyan
    Color(0xFF2979FF), // Blue
    Color(0xFFD500F9), // Purple
    Color(0xFFFF4081)  // Pink
)

val TODDLER_PALETTE_COLORS_4 = listOf(
    Color(0xFFFF1744), // Red
    Color(0xFFFFD600), // Yellow
    Color(0xFF2979FF), // Blue
    Color(0xFF00E676)  // Green
)

val FUN_STAMPS = listOf("🐾", "⭐", "🌸", "🦆", "🥟", "🐱")

data class SpongeBubble(
    val id: Long,
    var x: Float,
    var y: Float,
    var vx: Float,
    var vy: Float,
    var size: Float,
    val color: Color
)

@Composable
fun CanvasZone(
    repository: GameRepository,
    soundPlayer: SoundEffectPlayer,
    modifier: Modifier = Modifier
) {
    FingerPaintingScreen(repository = repository, soundPlayer = soundPlayer, modifier = modifier)
}

@Composable
fun FingerPaintingScreen(
    repository: GameRepository,
    soundPlayer: SoundEffectPlayer,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val soundManager = remember(soundPlayer) { SoundManager(context, soundPlayer) }
    val haptics = rememberHaptics()
    val ageProfile = LocalAgeProfile.current
    val strokes = remember { mutableStateListOf<MultitouchStroke>() }
    val stamps = remember { mutableStateListOf<StampElement>() }
    val bubbles = remember { mutableStateListOf<SpongeBubble>() }
    val gameState by repository.gameState.collectAsState()

    val colors = if (ageProfile.isToddler2) TODDLER_PALETTE_COLORS_4 else PALETTE_COLORS_8

    var selectedColor by remember { mutableStateOf(colors[0]) }
    // OFF by default: Normal solid color line mode
    var isRainbowActive by remember { mutableStateOf(false) }
    var selectedBrushMode by remember { mutableStateOf(CanvasBrushMode.PASTEL_COLOR) }
    var selectedStamp by remember { mutableStateOf(FUN_STAMPS[0]) }
    var strokeWidth by remember { mutableFloatStateOf(if (ageProfile.isToddler2) 32f else 24f) }
    var lastPaintTime by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var showIdleHint by remember { mutableStateOf(false) }

    LaunchedEffect(lastPaintTime, ageProfile.isToddler2) {
        if (ageProfile.isToddler2 && ageProfile.autoDemoIdleDelaySeconds > 0) {
            showIdleHint = false
            delay(ageProfile.autoDemoIdleDelaySeconds * 1000L)
            showIdleHint = true
        }
    }

    val coroutineScope = rememberCoroutineScope()
    val clearBounce = remember { Animatable(1f) }

    // Cleaning bubble particles loop
    LaunchedEffect(Unit) {
        while (isActive) {
            if (bubbles.isNotEmpty()) {
                for (i in bubbles.indices.reversed()) {
                    val b = bubbles[i]
                    b.x += b.vx
                    b.y += b.vy
                    b.size -= 0.6f
                    if (b.size <= 0f) {
                        bubbles.removeAt(i)
                    }
                }
                delay(16)
            } else {
                delay(150)
            }
        }
    }

    fun triggerClearCanvas() {
        soundManager.play("whoosh")
        soundManager.play("chime")
        haptics.vibrate(30)

        strokes.clear()
        stamps.clear()

        repeat(28) {
            bubbles.add(
                SpongeBubble(
                    id = System.nanoTime() + it,
                    x = Random.nextFloat() * 800f + 40f,
                    y = Random.nextFloat() * 1000f + 100f,
                    vx = (Random.nextFloat() - 0.5f) * 14f,
                    vy = -(Random.nextFloat() * 10f + 4f),
                    size = Random.nextFloat() * 24f + 16f,
                    color = PALETTE_COLORS_8.random().copy(alpha = 0.7f)
                )
            )
        }

        coroutineScope.launch {
            clearBounce.snapTo(0.92f)
            clearBounce.animateTo(1f, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessLow))
        }
    }

    fun undoLastAction() {
        if (stamps.isNotEmpty() && (strokes.isEmpty() || stamps.last().id > strokes.last().id)) {
            stamps.removeAt(stamps.lastIndex)
        } else if (strokes.isNotEmpty()) {
            strokes.removeAt(strokes.lastIndex)
        }
        soundManager.play("pop")
        haptics.vibrateShort()
    }

    // Determine actual brush mode to pass to canvas
    val activeCanvasBrushMode = if (isRainbowActive) {
        CanvasBrushMode.RAINBOW_TRAIL
    } else {
        selectedBrushMode
    }

    var paperColorIndex by remember { mutableIntStateOf(0) }
    val currentPaperColor = PAPER_COLORS[paperColorIndex]

    val roomDecors = remember {
        listOf(
            DecorSpec(DecorKind.PLANT, 0.08f, 0.45f, 76f),
            DecorSpec(DecorKind.SUN, 0.90f, 0.12f, 72f, reaction = DecorReaction.SMILE),
            DecorSpec(DecorKind.STAR, 0.12f, 0.18f, 56f, reaction = DecorReaction.SPIN),
            DecorSpec(DecorKind.FLOWER, 0.92f, 0.45f, 60f),
            DecorSpec(DecorKind.BIRD, 0.90f, 0.28f, 58f),
            DecorSpec(DecorKind.FISH, 0.08f, 0.30f, 60f)
        )
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .statusBarsPadding()
            .navigationBarsPadding()
            .testTag("finger_painting_screen")
    ) {
        // 1. Vector 3-Layer Scene Background: ROOM
        SceneBackground(theme = SceneTheme.ROOM)

        // 2. Harmless room decor layer
        DecorLayer(items = roomDecors)

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalArrangement = Arrangement.SpaceBetween,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // TOP BAR: Home space, Paper Color Toggle, Clear Sponge & Undo Buttons
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Home button space (80 dp)
                    Spacer(modifier = Modifier.size(80.dp))

                    // 📄 Paper color toggle button (72 dp touch target)
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(64.dp)
                            .border(BorderStroke(3.dp, ColorInk), ShapeButton)
                            .background(currentPaperColor, ShapeButton)
                            .clip(ShapeButton)
                            .plasticineClickable(haptics = haptics) {
                                paperColorIndex = (paperColorIndex + 1) % PAPER_COLORS.size
                                soundManager.play("pop")
                                haptics.vibrateShort()
                            }
                            .testTag("paper_color_button")
                    ) {
                        Text("📄", fontSize = 28.sp)
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (!ageProfile.isToddler2) {
                        // Undo button (72 dp target)
                        Box(
                            contentAlignment = Alignment.Center,
                            modifier = Modifier
                                .size(64.dp)
                                .border(BorderStroke(3.dp, ColorInk), ShapeButton)
                                .background(ColorWhite, ShapeButton)
                                .clip(ShapeButton)
                                .plasticineClickable(haptics = haptics) {
                                    undoLastAction()
                                }
                        ) {
                            Text("↩️", fontSize = 28.sp)
                        }
                    }

                    // Clear Sponge button (72 dp target)
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(64.dp)
                            .border(BorderStroke(3.dp, ColorInk), ShapeButton)
                            .background(ColorYellow, ShapeButton)
                            .clip(ShapeButton)
                            .plasticineClickable(haptics = haptics) {
                                triggerClearCanvas()
                            }
                            .testTag("clear_canvas_button")
                    ) {
                        Text("🧽", fontSize = 32.sp)
                    }
                }
            }

            // CENTER: Canvas as Sheet of Paper with Yellow Plasticine Frame and 1° lively tilt
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .graphicsLayer { rotationZ = 1f }
                    .scale(clearBounce.value)
                    .clip(RoundedCornerShape(24.dp))
                    .background(currentPaperColor)
                    .border(6.dp, ColorYellow, RoundedCornerShape(24.dp))
                    .border(2.5.dp, ColorInk, RoundedCornerShape(24.dp))
            ) {
                MultitouchRainbowCanvas(
                    strokes = strokes,
                    stamps = stamps,
                    activeBrushMode = activeCanvasBrushMode,
                    selectedColor = selectedColor,
                    selectedStamp = selectedStamp,
                    strokeWidth = strokeWidth,
                    soundPlayer = soundPlayer,
                    onStrokeAdded = { repository.addCoins(1) },
                    palmRejectionEnabled = gameState.palmRejectionEnabled,
                    edgeMarginDp = gameState.palmRejectionMarginDp
                )

                // Render Stamps
                stamps.forEach { stamp ->
                    Text(
                        text = stamp.emoji,
                        fontSize = (stamp.size * 0.9f).sp,
                        modifier = Modifier
                            .align(Alignment.TopStart)
                            .padding(
                                start = (stamp.x - stamp.size * 0.5f).dp,
                                top = (stamp.y - stamp.size * 0.5f).dp
                            )
                    )
                }

                // Render Clear Sponge Bubbles
                Canvas(modifier = Modifier.fillMaxSize()) {
                    bubbles.forEach { b ->
                        drawCircle(
                            color = b.color,
                            radius = b.size,
                            center = Offset(b.x, b.y)
                        )
                        drawCircle(
                            color = Color.White.copy(alpha = 0.85f),
                            radius = b.size * 0.32f,
                            center = Offset(b.x - b.size * 0.3f, b.y - b.size * 0.3f)
                        )
                    }
                }
            }

            // BOTTOM CONTROL PANELS (Effects, Palette with Rainbow, Size Selector)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // 1. BRUSH EFFECTS / STAMPS ROW (72 dp buttons, icons only)
                if (selectedBrushMode == CanvasBrushMode.ANIMAL_STAMP) {
                    // Row of 6 Large Stamp Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        FUN_STAMPS.forEach { stamp ->
                            val isSelected = selectedStamp == stamp
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier
                                    .size(56.dp)
                                    .border(
                                        BorderStroke(if (isSelected) 3.5.dp else 2.dp, if (isSelected) ColorPink else ColorInk),
                                        CircleShape
                                    )
                                    .background(if (isSelected) ColorWhite else ColorBgSoft, CircleShape)
                                    .clip(CircleShape)
                                    .plasticineClickable(haptics = haptics) {
                                        selectedStamp = stamp
                                        soundManager.play("pop")
                                    }
                            ) {
                                Text(stamp, fontSize = 28.sp)
                            }
                        }
                    }
                } else {
                    // Row of Effect Icon Buttons
                    val availableEffects = if (ageProfile.isToddler2) {
                        listOf(
                            CanvasBrushMode.PASTEL_COLOR to "🖌️",
                            CanvasBrushMode.NEON_GLOW to "✨",
                            CanvasBrushMode.MAGIC_BUBBLES to "🫧"
                        )
                    } else {
                        listOf(
                            CanvasBrushMode.PASTEL_COLOR to "🖌️",
                            CanvasBrushMode.NEON_GLOW to "✨",
                            CanvasBrushMode.MAGIC_BUBBLES to "🫧",
                            CanvasBrushMode.ANIMAL_STAMP to "🐾"
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        availableEffects.forEach { (mode, emoji) ->
                            val isSelected = selectedBrushMode == mode && !isRainbowActive
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier
                                    .size(58.dp)
                                    .border(
                                        BorderStroke(if (isSelected) 3.5.dp else 2.dp, if (isSelected) ColorPurple else ColorInk),
                                        ShapeButton
                                    )
                                    .background(if (isSelected) ColorWhite else ColorBgSoft, ShapeButton)
                                    .clip(ShapeButton)
                                    .plasticineClickable(haptics = haptics) {
                                        selectedBrushMode = mode
                                        isRainbowActive = false
                                        soundManager.play("chime")
                                    }
                            ) {
                                Text(emoji, fontSize = 30.sp)
                            }
                        }
                    }
                }

                // 2. PALETTE & RAINBOW TOGGLE (8 colors in 2x4 grid or 4 colors + 🌈 button)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Colors Grid
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(4),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        items(colors) { color ->
                            val isSelected = selectedColor == color && !isRainbowActive
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier
                                    .height(48.dp)
                                    .border(
                                        BorderStroke(if (isSelected) 3.5.dp else 2.dp, if (isSelected) ColorInk else Color.White),
                                        RoundedCornerShape(16.dp)
                                    )
                                    .background(color, RoundedCornerShape(16.dp))
                                    .clip(RoundedCornerShape(16.dp))
                                    .plasticineClickable(haptics = haptics) {
                                        selectedColor = color
                                        isRainbowActive = false
                                        if (selectedBrushMode == CanvasBrushMode.ANIMAL_STAMP) {
                                            selectedBrushMode = CanvasBrushMode.PASTEL_COLOR
                                        }
                                        soundManager.play("pop")
                                    }
                            ) {
                                if (isSelected) {
                                    Text("✓", color = Color.White, fontWeight = FontWeight.Black, fontSize = 20.sp)
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.width(10.dp))

                    // 🌈 RAINBOW Button (OFF by default, toggles rainbow trail)
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(height = if (colors.size > 4) 102.dp else 48.dp, width = 64.dp)
                            .border(
                                BorderStroke(if (isRainbowActive) 4.dp else 2.dp, if (isRainbowActive) ColorPurple else ColorInk),
                                ShapeButton
                            )
                            .background(if (isRainbowActive) ColorWhite else ColorBgSoft, ShapeButton)
                            .clip(ShapeButton)
                            .plasticineClickable(haptics = haptics) {
                                isRainbowActive = !isRainbowActive
                                soundManager.play("magic")
                            }
                    ) {
                        Text("🌈", fontSize = 32.sp)
                    }
                }

                // 3. BRUSH SIZE SELECTOR (3 Circles S, M, L without text, Hidden for 2yo)
                if (!ageProfile.isToddler2) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        listOf(
                            14f to 12.dp,
                            28f to 22.dp,
                            48f to 34.dp
                        ).forEach { (size, dotR) ->
                            val isSelected = strokeWidth == size
                            Box(
                                contentAlignment = Alignment.Center,
                                modifier = Modifier
                                    .size(52.dp)
                                    .border(
                                        BorderStroke(if (isSelected) 3.5.dp else 1.5.dp, if (isSelected) ColorInk else ColorInk.copy(alpha = 0.3f)),
                                        CircleShape
                                    )
                                    .background(if (isSelected) ColorYellow else ColorWhite, CircleShape)
                                    .clip(CircleShape)
                                    .plasticineClickable(haptics = haptics) {
                                        strokeWidth = size
                                        soundManager.play("pop")
                                    }
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(dotR)
                                        .clip(CircleShape)
                                        .background(ColorInk)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
